import Login from './Components/Login';
import Viewitem from './Components/Admin/Viewitem';
import './App.css';
import { Route, Routes } from 'react-router-dom'
import Tiffintype from './Components/Tiffindescription';
import SignUp from './Components/Signup';
import Home from './Home';
import AdminViews from './Components/Admin/AdminView';
import NoteState from './useContext/NotState';
import View_cart from './Components/Shopping';
import LoginPayment from './Components/LoginPayment';
import Bill from './Components/Bill/Bill';
import Payment from './Components/Bill/Payment';
import Provider from './Components/Admin/Provider';
// import Search from './Search';


function Front() {
  return (
    <>
      {/* <Login/> */}
      <NoteState />
      <div>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/home" element={<Home />} />
          <Route exact path="/signup" element={<SignUp />} />
          <Route exact path="/login" element={<Login />} />
          <Route exact path="/tiffindescription" element={<Tiffintype />} />
          <Route exact path="/viewitem" element={<Viewitem />}  target='blank'/>
          <Route exact path="/adminview" element={<AdminViews />} />
          <Route exact path="/cart" element={<View_cart />} />
          <Route exact path="/loginpayment" element={<LoginPayment />} />
          <Route exact path="/payment" element={<Payment />} />
          <Route exact path="/bill" element={<Bill />} />
          <Route exact path="/provider" element={<Provider />} />


        </Routes>
      </div>

    </>
  );
}

export default Front;
