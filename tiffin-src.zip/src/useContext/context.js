import React from 'react'

export default function context() {
  return (
    <div>context</div>
  )
}
