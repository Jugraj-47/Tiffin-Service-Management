import React from 'react';
import { useState } from "react";

import ProviderList from '../Admin/ProviderList';
import SearchIcon from '@mui/icons-material/Search';

function Menu() {
  const [srch, setSrch] = useState('pop');
  const [text, setText] = useState('');

  function handleSearch() {
    setSrch(text);
  }

  function handleText(e) {
    e.preventDefault();
    setText(e.target.value);
  }


  return (
    <div>
        <br/>
        <br/>
        <br/>
      
        <div className='searchmain'>
          <input type='text' value={text} placeholder='enter your city' onChange={handleText} required />
          <SearchIcon fontSize="large" onClick={handleSearch}>
          </SearchIcon>
        </div>
      
        <div>
          <ProviderList find={srch} />
        </div>
  
    </div>
    
      );
}

export default Menu;

